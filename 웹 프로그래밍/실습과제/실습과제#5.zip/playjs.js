function calc(){
	var x = document.getElementById("x");
	var y = document.getElementById("y");
	var sum = document.getElementById("sum");

	sum.value = parseInt(x.value)+parseInt(y.value);
}